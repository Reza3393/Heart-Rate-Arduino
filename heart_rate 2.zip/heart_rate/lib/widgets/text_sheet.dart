import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:heart_rate/helper/app_colors.dart';

class TextSheet extends StatelessWidget {
  final String text;
  final TextAlign? textAlign;
  final Color? color;
  final double? size;
  final FontWeight? fontWeight;
  final TextDecoration? decoration;
  final TextOverflow? overflow;
  final int? maxLines;
  final String fontFamily;
  final double? letterSpacing;
  final double? height;

  const TextSheet({
    super.key,
    required this.text,
    this.textAlign,
    this.color,
    this.size,
    this.fontWeight,
    this.decoration,
    this.overflow,
    this.maxLines,
    this.fontFamily = "poppins",
    this.letterSpacing,
    this.height,
  });

  const TextSheet.nunito({
    super.key,
    required this.text,
    this.textAlign,
    this.color,
    this.size,
    this.fontWeight,
    this.decoration,
    this.overflow,
    this.maxLines,
    this.fontFamily = "nunito",
    this.letterSpacing,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
      style: style(),
    );
  }

  TextStyle style() {
    if (fontFamily == "nunito") {
      return GoogleFonts.nunitoSans(
        color: color ?? AppColors.text,
        fontSize: size,
        fontWeight: fontWeight ?? FontWeight.w700,
        decoration: decoration,
        decorationColor: color ?? AppColors.text,
        letterSpacing: letterSpacing ?? -0.5,
        height: height,
      );
    } else {
      return GoogleFonts.poppins(
        color: color ?? AppColors.text,
        fontSize: size,
        fontWeight: fontWeight ?? FontWeight.w400,
        decoration: decoration,
        decorationColor: color ?? AppColors.text,
        letterSpacing: letterSpacing,
        height: height,
      );
    }
  }
}
