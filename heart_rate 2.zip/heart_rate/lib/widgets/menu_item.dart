import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/widgets/text_sheet.dart';

class MenuItem extends StatelessWidget {
  final String imageUrl;
  final String title;
  final void Function()? onTap;

  const MenuItem({super.key, required this.imageUrl, required this.title, this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*0.125,
      child: Card(
        color: AppColors.bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15)
        ),
        margin: EdgeInsets.zero,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(15),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 15,
            ),
            child: Row(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width*0.2,
                  height: MediaQuery.of(context).size.width*0.15,
                  child: Image.asset(
                      imageUrl
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextSheet(
                    text: title,
                    size: 20,
                    fontWeight: FontWeight.w700,
                    color: AppColors.pink,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}