import 'package:flutter/material.dart';
import 'package:heart_rate/widgets/text_sheet.dart';

class InformationList extends StatelessWidget {
  final String title;
  final List<String> list;
  final int typeList;

  const InformationList({super.key, required this.title, required this.list, this.typeList = 0});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextSheet(
          text: title,
          size: 16,
          fontWeight: FontWeight.w700,
          color: Colors.black,
        ),
        SizedBox(height: 2),
        ListView.separated(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: list.length,
          itemBuilder: (context, index) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 32,
                  padding: EdgeInsets.only(left: 8),
                  child: TextSheet(
                    text: typeList == 0 ? "${index+1}. " : "· ",
                    size: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
                Expanded(
                  child: TextSheet(
                    text: list[index],
                    size: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
              ],
            );
          },
          separatorBuilder: (context, index) => SizedBox(height: 5),
        ),
      ],
    );
  }
}
