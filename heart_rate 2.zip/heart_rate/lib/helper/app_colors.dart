import 'package:flutter/material.dart';

class AppColors {
  static const Color pink = Color(0xFFF00E46);
  static const Color pinkChart = Color(0xFFFF33BB);
  static const Color text = Color(0xFF363636);
  static const Color bgCard = Color(0xFFF1F1F1);
  // static const Color bgCard = Color(0xFFffff00);
}