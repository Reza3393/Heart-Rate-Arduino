import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FirestoreService {
  static void addBpmHistory({
    required Timestamp createdAt,
    required num rate
  }) {
      CollectionReference colRef = FirebaseFirestore.instance.collection("bpm_history");

      colRef.add({
        'rate': rate,
        'created_at': createdAt,
      }).then((value) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   // const SnackBar(content: Text("Berhasil menambahkan data", style: TextStyle(color: Colors.white)), backgroundColor: Colors.green, behavior: SnackBarBehavior.floating, duration: Duration(milliseconds: 200))
        // );

        print("Berhasil menambahkan data");
      }).catchError((error) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(content: Text("Gagal: $error", style: const TextStyle(color: Colors.white)), backgroundColor: Colors.red, behavior: SnackBarBehavior.floating, duration: const Duration(milliseconds: 200))
        // );

        print("Gagal: $error");
      });
  }

  static Future<void> deleteBpmHistory(BuildContext context, {
    required String docId,
  }) async {
      CollectionReference colRef = FirebaseFirestore.instance.collection("bpm_history");

      colRef.doc(docId).delete()
          .then((value) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Berhasil menghapus data", style: TextStyle(color: Colors.white)), backgroundColor: Colors.green, behavior: SnackBarBehavior.floating, duration: Duration(milliseconds: 500))
        );
      }).catchError((error) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Gagal: $error", style: const TextStyle(color: Colors.white)), backgroundColor: Colors.red, behavior: SnackBarBehavior.floating, duration: const Duration(milliseconds: 500))
        );
      });
  }
}