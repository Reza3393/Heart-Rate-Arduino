import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class HeartRateMonitor extends StatefulWidget {
  @override
  _HeartRateMonitorState createState() => _HeartRateMonitorState();
}

class _HeartRateMonitorState extends State<HeartRateMonitor> {
  List<HeartRateData> data = [];

  late ChartSeriesController _chartSeriesController;

  Timer? timer;

  final Random random = Random();

  double count = 20;

  @override
  void initState() {
    super.initState();

    data = getInitialData();

    timer = Timer.periodic(const Duration(milliseconds: 100), _updateDataSource);
  }

  void _updateDataSource(Timer timer) {
    data.add(HeartRateData(count, _getRandomInt(60, 120).toDouble()));
    if (data.length >= 20) {
      data.removeAt(0);
      _chartSeriesController.updateDataSource(
        addedDataIndexes: <int>[data.length - 1],
        removedDataIndexes: <int>[0],
      );
    } else {
      _chartSeriesController.updateDataSource(
        addedDataIndexes: <int>[data.length - 1],
      );
    }
    count = count + 1;
  }

  List<HeartRateData> getInitialData() {
    return List.generate(count.toInt(), (index) => HeartRateData(index.toDouble(), _getRandomInt(60, 120).toDouble()));
  }

  num _getRandomInt(int min, int max) {
    return min + random.nextInt(max - min);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Heart Rate Monitor'),
      ),
      body: SfCartesianChart(
        margin: EdgeInsets.zero,
        primaryXAxis: NumericAxis(
          majorGridLines: MajorGridLines(width: 0),
          interval: 1,
          edgeLabelPlacement: EdgeLabelPlacement.shift,
          isVisible: false,
        ),
        primaryYAxis: NumericAxis(
          majorGridLines: MajorGridLines(width: 0),
          isVisible: false,
          minimum: 40,
          maximum: 200,
          interval: 10,
        ),
        series: <CartesianSeries>[
          AreaSeries<HeartRateData, double>(
            dataSource: data,
            xValueMapper: (HeartRateData data, _) => data.time,
            yValueMapper: (HeartRateData data, _) => data.rate,
            gradient: LinearGradient(
              colors: [
                AppColors.pinkChart.withOpacity(0.4),
                Colors.white,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderColor: AppColors.pinkChart,
            borderWidth: 2,
            onRendererCreated: (ChartSeriesController controller) {
              _chartSeriesController = controller;
            },
          ),
        ],
      ),
    );
  }
}

class HeartRateData {
  final double time;
  final double rate;

  HeartRateData(this.time, this.rate);
}
