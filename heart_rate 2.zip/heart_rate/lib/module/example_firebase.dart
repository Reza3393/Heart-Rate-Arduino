import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ExampleFirebase extends StatefulWidget {
  const ExampleFirebase({super.key});

  @override
  State<ExampleFirebase> createState() => _ExampleFirebaseState();
}

class _ExampleFirebaseState extends State<ExampleFirebase> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: FutureBuilder<QuerySnapshot>(
        future: getdata(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text("Something went wrong");
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Text("Tunggu");
          }

          if (!snapshot.hasData) {
            print(snapshot);
            return Text("Document does not exist");
          }

          if (snapshot.connectionState == ConnectionState.done) {
            List<QueryDocumentSnapshot<Object?>> data = snapshot.data!.docs;

            return ListView.separated(
              itemCount: data.length,
              itemBuilder: (context, index) {
                return Text("Full Name: ${data[index]['full_name']} ${data[index]['company']}");
              },
              separatorBuilder: (context, index) => SizedBox(height: 20),
            );
          }

          return Text("loading");
        },
      ),
    );
  }

  Future<QuerySnapshot> getdata() async {
    CollectionReference users = FirebaseFirestore.instance.collection('users');

    return users.get();
  }
}
