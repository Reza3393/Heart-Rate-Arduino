// ignore_for_file: avoid_print

import 'dart:async';

import 'package:basic_utils/basic_utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/helper/firestore_service.dart';
import 'package:heart_rate/widgets/text_sheet.dart';
import 'package:lottie/lottie.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class HomePage extends StatefulWidget {
  final double bottomPadding;
  const HomePage({super.key, this.bottomPadding = 0});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DatabaseReference starCountRef = FirebaseDatabase.instance.ref('Sensor');
  StreamSubscription<DatabaseEvent>? _subscription;
  List<HeartRateData> data = [];

  late ChartSeriesController _chartSeriesController;

  double count = 1;
  double minimumChart = 40;
  double maximumChart = 140;

  num bpm = 0;
  num minBpm = 0;
  num maxBpm = 0;

  List<num> listBpm = [];

  String status = "--";

  @override
  void initState() {
    super.initState();

    print("HOME");

    listenFirebase();
  }

  @override
  void dispose() {
    super.dispose();

    _subscription?.cancel();
  }

  void updateBpmChart(double bpmValue) {
    data.add(HeartRateData(count, bpmValue));

    if (data.length >= 10) {
      data.removeAt(0);
      _chartSeriesController.updateDataSource(
        addedDataIndexes: <int>[data.length - 1],
        removedDataIndexes: <int>[0],
      );
    } else {
      _chartSeriesController.updateDataSource(
        addedDataIndexes: <int>[data.length - 1],
      );
    }

    count = count + 1;
  }

  void listenFirebase() {
    _subscription = starCountRef.onValue.listen((DatabaseEvent event) {
      final data = event.snapshot.value;

      print("REALTIME");
      print(data);

      if (StringUtils.equalsIgnoreCase(data.toString(), "No Finger") || StringUtils.equalsIgnoreCase(data.toString(), "Tidak ada jari")) {
        if (mounted) {
          setState(() {
            bpm = 0;
            listBpm.clear();
            status = statuses(-1);
          });
        }
      } else {
        if (StringUtils.isDigit(data.toString())) {
          if (mounted) {
            setState(() {
              bpm = num.parse(data.toString());

              if (bpm > 0) {
                listBpm.add(bpm);

                if (listBpm.isNotEmpty) {
                  maxBpm = listBpm.reduce((a, b) => a > b ? a : b);
                  minBpm = listBpm.reduce((a, b) => a < b ? a : b);
                }
                status = statuses(bpm);
                maxBpm = listBpm.reduce((a, b) => a > b ? a : b);
                minBpm = listBpm.reduce((a, b) => a < b ? a : b);

                status = statuses(bpm);

                updateBpmChart(bpm.toDouble());

                FirestoreService.addBpmHistory(createdAt: Timestamp.now(), rate: bpm);
              }
            });
          }
        }
      }
    });
  }

  String statuses(num value) {
    if (value >= 60 && value <= 100) {
      return "NORMAL";
    } else if (value == -1) {
      return "--";
    } else {
      return "TIDAK NORMAL";
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(20),
              width: MediaQuery.of(context).size.width,
              child: Card(
                color: AppColors.bgCard,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50)
                ),
                margin: EdgeInsets.zero,
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 2),
                  child: TextSheet.nunito(
                    text: "Monitoring Detak Jantung",
                    size: 23,
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.only(
                  top: 10,
                  left: 20,
                  right: 20,
                  bottom: 20+(widget.bottomPadding),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width,
                                child: Card(
                                  color: AppColors.bgCard,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)
                                  ),
                                  margin: EdgeInsets.zero,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 15,
                                      vertical: 25,
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const TextSheet(
                                          text: "MAX",
                                          size: 18,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black,
                                        ),
                                        const SizedBox(height: 5),
                                        TextSheet(
                                          text: maxBpm > 0 ? maxBpm.toStringAsFixed(0) : "--",
                                          size: 32,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.pink,
                                        ),
                                        const SizedBox(height: 5),
                                        const TextSheet(
                                          text: "BPM",
                                          size: 16,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 15),
                              SizedBox(
                                width: MediaQuery.of(context).size.width,
                                child: Card(
                                  color: AppColors.bgCard,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)
                                  ),
                                  margin: EdgeInsets.zero,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 15,
                                      vertical: 25,
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const TextSheet(
                                          text: "MIN",
                                          size: 18,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black,
                                        ),
                                        const SizedBox(height: 5),
                                        TextSheet(
                                          text: minBpm > 0 ? minBpm.toStringAsFixed(0) : "--",
                                          size: 32,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.pink,
                                        ),
                                        const SizedBox(height: 5),
                                        const TextSheet(
                                          text: "BPM",
                                          size: 16,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height*0.55,
                            child: Card(
                              color: AppColors.bgCard,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15)
                              ),
                              margin: EdgeInsets.zero,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 10),
                                      child: TextSheet(
                                        text: "Heart Rate",
                                        size: 18,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Center(
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 25),
                                        child: Lottie.asset(
                                          "assets/lottie/heart.json",
                                          frameRate: FrameRate(60),
                                          width: MediaQuery.of(context).size.width,
                                          repeat: true,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Expanded(
                                      child: SfCartesianChart(
                                        plotAreaBorderWidth: 0,
                                        margin: EdgeInsets.zero,
                                        primaryXAxis: const NumericAxis(
                                          majorGridLines: MajorGridLines(width: 0),
                                          interval: 1,
                                          edgeLabelPlacement: EdgeLabelPlacement.shift,
                                          isVisible: false,
                                        ),
                                        primaryYAxis: NumericAxis(
                                          majorGridLines: const MajorGridLines(width: 0),
                                          isVisible: false,
                                          minimum: minimumChart,
                                          maximum: maximumChart,
                                          interval: 10,
                                        ),
                                        series: <CartesianSeries>[
                                          AreaSeries<HeartRateData, double>(
                                            dataSource: data,
                                            xValueMapper: (HeartRateData data, _) => data.time,
                                            yValueMapper: (HeartRateData data, _) => data.rate,
                                            gradient: LinearGradient(
                                              colors: [
                                                AppColors.pinkChart.withOpacity(0.4),
                                                AppColors.bgCard,
                                              ],
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                            ),
                                            borderColor: AppColors.pinkChart,
                                            borderWidth: 2,
                                            onRendererCreated: (ChartSeriesController controller) {
                                              _chartSeriesController = controller;
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 10),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          FittedBox(
                                            child: TextSheet(
                                              text: bpm > 0 ? bpm.toStringAsFixed(0) : "No Finger",
                                              size: 48,
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.pink,
                                            ),
                                          ),
                                          const TextSheet(
                                            text: "BPM",
                                            size: 32,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    const Center(
                      child: TextSheet(
                        text: "STATUS :",
                        size: 20,
                        fontWeight: FontWeight.w700,
                        textAlign: TextAlign.center,
                        color: Color(0xFF786665),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: Card(
                        color: AppColors.bgCard,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)
                        ),
                        margin: EdgeInsets.zero,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: TextSheet(
                            text: status,
                            size: 32,
                            fontWeight: FontWeight.w700,
                            textAlign: TextAlign.center,
                            color: AppColors.pink,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HeartRateData {
  final double time;
  final double rate;

  HeartRateData(this.time, this.rate);
}