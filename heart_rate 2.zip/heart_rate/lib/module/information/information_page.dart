import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/helper/navigators.dart';
import 'package:heart_rate/module/information/aritmia_information_page.dart';
import 'package:heart_rate/module/information/detak_jantung_normal_information_page.dart';
import 'package:heart_rate/widgets/menu_item.dart';
import 'package:heart_rate/widgets/text_sheet.dart';

class InformationPage extends StatelessWidget {
  final double bottomPadding;

  const InformationPage({super.key, this.bottomPadding = 0});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(20),
              width: MediaQuery.of(context).size.width,
              child: Card(
                color: AppColors.bgCard,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50)
                ),
                margin: EdgeInsets.zero,
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 2),
                  child: TextSheet.nunito(
                    text: "Informasi",
                    size: 23,
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.only(
                  left: 20,
                  top: 10,
                  right: 20,
                  bottom: 20+(bottomPadding),
                ),
                child: Column(
                  children: [
                    MenuItem(
                      imageUrl: "assets/image/jantung.png",
                      title: "Aritmia",
                      onTap: () {
                        Navigators.push(context, AritmiaInformationPage());
                      },
                    ),
                    const SizedBox(height: 20),
                    MenuItem(
                      imageUrl: "assets/image/detak-jantung.png",
                      title: "Detak Jantung Normal",
                      onTap: () {
                        Navigators.push(context, DetakJantungNormalInformationPage());
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}