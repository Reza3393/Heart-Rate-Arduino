import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/widgets/information_list.dart';
import 'package:heart_rate/widgets/text_sheet.dart';

class DetakJantungNormalInformationPage extends StatelessWidget {
  DetakJantungNormalInformationPage({super.key});

  final String title = "Detak Jantung Normal";
  final String description = "Detak jantung normal manusia bisa berbeda-beda, terlebih jika dilihat dari perbedaan usia. Meski begitu, detak jantung akan selalu menurun seiring dengan bertambahnya usia, ketika seseorang melewati masa kanak-kanak menuju dewasa.";
  final List<String> listDetails = [
    "Bayi baru lahir (100 - 160 bpm)",
    "Bayi umur 0 - 5 bulan (90 - 150 bpm)",
    "Bayi umur 6 - 12 bulan (80 - 140 bpm)",
    "Balita umur 1 - 3 tahun (80 - 130 bpm)",
    "Balita umur 3 - 4 tahun (80 - 120 bpm)",
    "Anak umur 6 - 10 tahun (70 - 110 bpm)",
    "Anak umur 11 - 14 tahun (60 - 105 bpm)",
    "Remaja umur 15 tahun ke atas (60 - 100 bpm)",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.pink,
        title: const TextSheet(
          text: "INFORMASI",
          size: 24,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
        iconTheme: const IconThemeData(
          color: Colors.white
        ),
      ),
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IntrinsicHeight(
              child: Row(
                children: [
                  const VerticalDivider(
                    color: Color(0xFF0C8EA6),
                    thickness: 3,
                  ),
                  const SizedBox(width: 20),
                  TextSheet(
                    text: title,
                    size: 24,
                    fontWeight: FontWeight.w700,
                    color: AppColors.pink,
                  )
                ],
              )
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Card(
                color: AppColors.bgCard,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)
                ),
                margin: EdgeInsets.zero,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 20,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextSheet(
                        text: description,
                        size: 16,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                      ),
                      const SizedBox(height: 30),
                      InformationList(
                        title: "Untuk lebih detailnya, berikut perkiraan detak jantung normal pada manusia berdasarkan umur dalam satuan bpm (denyut per menit):",
                        list: listDetails,
                        typeList: 1,
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
