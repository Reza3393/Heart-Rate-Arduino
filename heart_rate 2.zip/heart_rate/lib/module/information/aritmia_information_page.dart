import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/widgets/information_list.dart';
import 'package:heart_rate/widgets/text_sheet.dart';

class AritmiaInformationPage extends StatelessWidget {
  AritmiaInformationPage({super.key});

  final String title = "Aritmia";
  final String description = "Aritmia adalah gangguan yang terjadi pada irama jantung. Penderita aritmia bisa merasakan irama jantungnya terlalu cepat (lebih dari 100 Bpm), terlalu lambat (kurang dari 60 Bpm), atau tidak teratur";
  final List<String> gejalaAritmia = [
    "Hilangnya kesadaran secara tiba-tiba",
    "Kesulitan bernapas",
    "Sakit kepala",
    "Sakit pada bagian dada",
    "Badan terasa mudah lelah",
    "Jantung berdetak lebih lambat",
    "Jantung berdetak sangat cepat",
  ];
  final List<String> penyebabAritmia = [
    "Penyalahgunaan alkohol",
    "Diabetes",
    "Konsumsi kafein berlebihan",
    "Penyakit jantung",
    "Hipertensi",
    "Gangguan hormonal",
    "Tegang atau stres emosional",
    "Jaringan parut di jantung menjadi pemicu serangan jantung",
    "Merokok",
    "Mengonsumsi obat-obatan",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.pink,
        title: const TextSheet(
          text: "INFORMASI",
          size: 24,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
        iconTheme: const IconThemeData(
          color: Colors.white
        ),
      ),
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IntrinsicHeight(
              child: Row(
                children: [
                  const VerticalDivider(
                    color: Color(0xFF0C8EA6),
                    thickness: 3,
                  ),
                  const SizedBox(width: 20),
                  TextSheet(
                    text: title,
                    size: 24,
                    fontWeight: FontWeight.w700,
                    color: AppColors.pink,
                  )
                ],
              )
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Card(
                color: AppColors.bgCard,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)
                ),
                margin: EdgeInsets.zero,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 20,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextSheet(
                        text: description,
                        size: 16,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                      ),
                      const SizedBox(height: 30),
                      InformationList(
                        title: "Gejala Aritmia",
                        list: gejalaAritmia
                      ),
                      const SizedBox(height: 30),
                      InformationList(
                        title: "Pemicu dan Penyebab Aritmia",
                        list: penyebabAritmia
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
