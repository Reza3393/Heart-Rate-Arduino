// ignore_for_file: use_build_context_synchronously, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/helper/firestore_service.dart';
import 'package:heart_rate/helper/navigators.dart';
import 'package:heart_rate/widgets/text_sheet.dart';
import 'package:intl/intl.dart';

class HistoryPage extends StatefulWidget {
  final double bottomPadding;

  const HistoryPage({super.key, this.bottomPadding = 0});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final ScrollController controller = ScrollController();

  @override
  void initState() {
    super.initState();

    print("HISTORY");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(20),
              width: MediaQuery.of(context).size.width,
              child: Card(
                color: AppColors.bgCard,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50)
                ),
                margin: EdgeInsets.zero,
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 2),
                  child: TextSheet.nunito(
                    text: "Riwayat",
                    size: 23,
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Scrollbar(
                controller: controller,
                thickness: 5,
                radius: const Radius.circular(50),
                interactive: true,
                thumbVisibility: true,
                child: SingleChildScrollView(
                  controller: controller,
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.only(
                    left: 10,
                    top: 10,
                    right: 10,
                    bottom: 20+(widget.bottomPadding),
                  ),
                  child: DottedBorder(
                    color: const Color(0xFF9747FF),
                    strokeWidth: 1,
                    radius: const Radius.circular(5),
                    borderType: BorderType.RRect,
                    padding: const EdgeInsets.all(15),
                    dashPattern: const [10, 5],
                    child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('bpm_history')
                          .orderBy('created_at', descending: true)
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }

                        if (snapshot.hasData && snapshot.data!.docs.isEmpty) {
                          return const Center(
                            child: Text("Tidak ada Data"),
                          );
                        }

                        List<QueryDocumentSnapshot<Object?>> queryDocumentSnapshot = snapshot.data!.docs;

                        return ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: queryDocumentSnapshot.length,
                          itemBuilder: (context, index) {
                            QueryDocumentSnapshot<Object?> item = queryDocumentSnapshot[index];
                            num rate = item["rate"];
                            Timestamp createdAt = getTimestamp(item);

                            return InkWell(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      content: const Text("Apakah Anda yakin ingin menghapus data ini?"),
                                      actions: [
                                        ElevatedButton(
                                          onPressed: () => Navigators.pop(context),
                                          child: const Text("Tidak"),
                                        ),
                                        ElevatedButton(
                                          onPressed: () async {
                                            await FirestoreService.deleteBpmHistory(context, docId: item.id);

                                            Navigators.pop(context);
                                          },
                                          child: const Text("Iya"),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                              child: SizedBox(
                                width: MediaQuery.of(context).size.width,
                                child: Card(
                                  color: AppColors.bgCard,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)
                                  ),
                                  margin: EdgeInsets.zero,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 15,
                                      vertical: 15,
                                    ),
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: MediaQuery.of(context).size.width*0.125,
                                          height: MediaQuery.of(context).size.width*0.15,
                                          child: Image.asset(
                                              "assets/image/hati.png"
                                          ),
                                        ),
                                        const SizedBox(width: 15),
                                        Expanded(
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              SizedBox(
                                                width: MediaQuery.of(context).size.width*0.365,
                                                child: FittedBox(
                                                  fit: BoxFit.scaleDown,
                                                  child: TextSheet(
                                                    text: DateFormat("dd-MM-yyyy HH.mm.ss").format(createdAt.toDate()),
                                                    size: 16,
                                                    fontWeight: FontWeight.w500,
                                                    color: Colors.black,
                                                    textAlign: TextAlign.start,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 10),
                                              Flexible(
                                                child: FittedBox(
                                                  fit: BoxFit.scaleDown,
                                                  child: TextSheet(
                                                    text: "Rate : ${rate.toStringAsFixed(0)} BPM",
                                                    size: 16,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.pink,
                                                    textAlign: TextAlign.end,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                          separatorBuilder: (context, index) => const SizedBox(height: 20),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Timestamp getTimestamp(QueryDocumentSnapshot<Object?> item) {
    try {
      return item["created_at"] as Timestamp;
    } catch (e) {
      return Timestamp.now();
    }
  }
}
