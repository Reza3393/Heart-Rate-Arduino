import 'package:flutter/material.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/helper/navigators.dart';
import 'package:heart_rate/module/home/home_page.dart';
import 'package:heart_rate/module/menu_navbar.dart';
import 'package:heart_rate/widgets/text_sheet.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextSheet.nunito(
                text: "Welcome to\nHeart Rate!",
                fontWeight: FontWeight.w700,
                size: 30,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height*0.1,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height*0.3,
                child: Image.asset(
                  "assets/image/logo.png"
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height*0.15,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width*0.5,
                child: FilledButton(
                  onPressed: () {
                    Navigators.push(context, MenuNavbar());
                  },
                  style: FilledButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50)
                    ),
                    backgroundColor: AppColors.pink,
                    foregroundColor: Colors.white,
                  ),
                  child: TextSheet.nunito(
                    text: "CONTINUE",
                    fontWeight: FontWeight.w600,
                    size: 23,
                    color: Colors.white,
                  )
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
