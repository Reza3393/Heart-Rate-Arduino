import 'package:flutter/material.dart';
import 'package:flutter_floating_bottom_bar/flutter_floating_bottom_bar.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/module/history/history_page.dart';
import 'package:heart_rate/module/home/home_page.dart';
import 'package:heart_rate/module/information/information_page.dart';

class MenuNavbar extends StatefulWidget {
  const MenuNavbar({super.key});

  @override
  State<StatefulWidget> createState() => _MenuNavbarState();
}

class _MenuNavbarState extends State<MenuNavbar> with SingleTickerProviderStateMixin {
  late int currentPage;
  late TabController tabController;

  @override
  void initState() {
    currentPage = 0;
    tabController = TabController(length: 3, vsync: this);
    tabController.animation?.addListener(
          () {
        final value = tabController.animation!.value.round();
        if (value != currentPage && mounted) {
          changePage(value);
        }
      },
    );
    super.initState();
  }

  void changePage(int newPage) {
    setState(() {
      currentPage = newPage;
    });
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 0,
      ),
      body: BottomBar(
        duration: const Duration(milliseconds: 500),
        width: MediaQuery.of(context).size.width * 0.8,
        borderRadius: BorderRadius.circular(20),
        barColor: AppColors.pink,
        barAlignment: Alignment.bottomCenter,
        body: (context, controller) => TabBarView(
          controller: tabController,
          physics: const NeverScrollableScrollPhysics(),
          children: const [
            HomePage(bottomPadding: kBottomNavigationBarHeight*1.25),
            InformationPage(bottomPadding: kBottomNavigationBarHeight*1.25),
            HistoryPage(bottomPadding: kBottomNavigationBarHeight*1.25),
          ],
        ),
        child: TabBar(
          controller: tabController,
          indicator: const BoxDecoration(),
          dividerHeight: 0,
          padding: const EdgeInsets.symmetric(vertical: 5),
          tabs: [
            Container(
              height: 50,
              width: 50,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: currentPage == 0 ? const Color(0xFFFF9A96) : Colors.transparent,
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                "assets/image/home.png"
              ),
            ),
            Container(
              height: 50,
              width: 50,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: currentPage == 1 ? const Color(0xFFFF9A96) : Colors.transparent,
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                  "assets/image/book.png"
              ),
            ),
            Container(
              height: 50,
              width: 50,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: currentPage == 2 ? const Color(0xFFFF9A96) : Colors.transparent,
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                  "assets/image/history.png"
              ),
            ),
          ],
        ),
      ),
    );
  }
}