import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:heart_rate/firebase_options.dart';
import 'package:heart_rate/module/welcome/welcome_page.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:heart_rate/helper/app_colors.dart';
import 'package:heart_rate/helper/dismissable_keyboard.dart';
import 'package:heart_rate/helper/navigators.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform
  );

  initializeDateFormatting("id");

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return DismissableKeyboard(
      child: MaterialApp(
        title: 'Heart Rate',
        debugShowCheckedModeBanner: false,
        navigatorKey: Navigators.navigatorState,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: AppColors.pink),
          useMaterial3: true,
        ),
        home: WelcomePage(),
      ),
    );
  }
}