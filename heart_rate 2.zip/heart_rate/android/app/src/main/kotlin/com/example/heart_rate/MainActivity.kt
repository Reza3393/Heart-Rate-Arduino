package com.example.heart_rate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
